//@line 36 "/build/buildd-iceweasel_10.0.12esr-1-armel-Th9U4j/iceweasel-10.0.12esr/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/build/buildd-iceweasel_10.0.12esr-1-armel-Th9U4j/iceweasel-10.0.12esr/browser/locales/en-US/firefox-l10n.js"

