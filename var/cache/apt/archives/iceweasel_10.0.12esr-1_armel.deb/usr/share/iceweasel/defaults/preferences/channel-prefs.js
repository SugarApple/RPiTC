//@line 2 "/build/buildd-iceweasel_10.0.12esr-1-armel-Th9U4j/iceweasel-10.0.12esr/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
